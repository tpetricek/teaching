# Silly bot

![Travis Build](https://api.travis-ci.com/tpetricek/silly-bot.svg?branch=master)

This is a very silly chat bot with no AI at all. 