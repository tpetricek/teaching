module.exports = {
  entry: './bot.js',
  output: {
    filename: 'bundle.js'
  },
  mode: 'development'
};